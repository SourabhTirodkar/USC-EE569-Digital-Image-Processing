
filename = 'Gallery.jpg';
width = 481; 
height = 321;  
BytesPerPixel = 1; 
%graph = read2Dimage(filename,width,height,BytesPerPixel); 

graph = imread('C:\Users\user\Desktop\USC Classes\Spring 2020\EE569- Digital Image Processing\Homeworks\HW #2\EE569_Spring_2020_HW2_Materials\Problem1\Gallery.jpg');


%% evaluate edge and ground truth mean  

prms1={ 'out','', 'thrs',1, 'maxDist',.0075, 'thin',1 } ; 
[thrs,cntR,sumR,cntP,sumP,V] = edgesEvalImg( graph, 'Gallery_GT5.mat', prms1 ); 
recall = cntR./sumR; 
precision = cntP./sumP;  
Fscore = 2*recall.*precision./(precision+recall);
precision 
recall
Fscore
imshow(graph)